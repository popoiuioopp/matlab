%Question 1 
f = @(x) 5-(5.*x)-(exp(0.5.*x));
figure('Name', 'Question 1');
hold on;
title('Question 1') 
x = linspace(-10, 10, 100);
plot(x, f(x),'g-');
plot(linspace(-10,10,100), zeros(100), '--');
root = 0.707071; %From 
plot(root, f(root), 'ro');

%Question 2 
%root = BisectionMethod(f,0,0,2); %NOT WORKING.
root = BisectionMethod(f,-1,1,2);
figure('Name', 'Question 2');
hold on;
title('Question 2')
x = linspace(-10, 10, 100);
plot(x, f(x),'g-');
plot(root, f(root), 'ro')
plot(linspace(-10,10,100), zeros(100), '--');


%Question 3 
root = NewtonRaphson(f, 0.7, 2); 
figure('Name', 'Question 3');
hold on;
title('Question 3')
x = linspace(-10, 10, 100);
plot(x, f(x),'g-');% plot กราฟของสมการ 
plot(root, f(root), 'ro'); % พล็อตจุดแดงในกราฟ 
plot(linspace(-10,10,100), zeros(100), '--');


%Question 4 
% Bisection method
n = 20;
iteration = 0; 
xl = -1; 
xu = 1;
result = (xl + xu)/2;
error_bisection = [];
while iteration < n
    iteration = iteration + 1;
    previous = result;
    if f(xl) * f(result) < 0
        xu = result;
    elseif f(xu) * f(result) < 0
        xl = result;
    end
    result = (xl + xu)/2;
    current = result;
    error_bisection(iteration) = abs((current - previous)/current);
end

%Newton-Raphson
n = 20;
iteration = 0; 
x0 = 1;
syms x;
f1 = matlabFunction(diff(f(x)));
x1 = f1(x0);
error_newton = [];
while iteration < n
    iteration = iteration + 1;
    x0 = x1;
    x1 = x0 - (f(x0)/f1(x0));
    error_newton(iteration) = abs((x1-x0)/x1);
end


figure('Name', 'Question 4');
title('Question 4')
hold on;
error_bisection(1) = []; 
error_newton(1) = [];
plot(linspace(1,n-1,n-1), error_bisection,'g-');
plot(linspace(1,n-1,n-1), error_newton,'c-');
legend('Bisection','Newton-Raphson');
xlabel('Iteration');
ylabel('Relative Errors');

